//
//  ViewController.swift
//  BlurrApp
//
//  Created by Sergey A. Kutylev on 4/26/2017.
//  Copyright © 2017 salahuddin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var backgroundImageView: UIImageView!
    
    let imageSet = ["ironman", "moscow", "paris", "paris", "moscow"]
	  let effects = ["extraLight", "light", "dark"]

    var blurEffectView: UIVisualEffectView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        super.viewDidLoad()
        
        // Randomly pick an image
        
        let selectedImageIndex = Int(arc4random_uniform(5))

			// Randomly pick an effect

			 // let selectedEffectIndex = Int(arc4random_uniform(3))
        // Apply blurring effect
        
        backgroundImageView.image = UIImage(named: imageSet[selectedImageIndex])
        
        let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.light)
        
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        
        blurEffectView?.frame = view.bounds
        
        backgroundImageView.addSubview(blurEffectView!)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        
        blurEffectView?.frame = view.bounds
        
    }


}

