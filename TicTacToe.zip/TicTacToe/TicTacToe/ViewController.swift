


import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var playerOneScore: UILabel!
    @IBOutlet weak var playerTwoScore: UILabel!
    
   
    var currentPlayer = 1
    var board = [0,0,0,0,0,0,0,0,0]
    var p1_score = 0
    var p2_score = 0
    var startGame = true

  
    let winningCombination = [ [0,1,2], [3,4,5], [6,7,8],
                                     [0,3,6], [1,4,7], [2,5,8],
                                     [0,4,8], [2,4,6]
    
                                    ]
    
    @IBOutlet var playAgainButt: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      playAgainButt.layer.cornerRadius = 6.0
       
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    
    @IBAction func makeMove(_ sender: UIButton) {
        
    if(board[sender.tag-1] == 0){
            board[sender.tag-1] = currentPlayer
            
            if(currentPlayer == 1){
                sender.setImage(UIImage(named:"player1.jpg"), for: UIControlState())
               
                currentPlayer = 2
            }
                
            else{
                sender.setImage(UIImage(named:"player2.jpg"), for: UIControlState())
                currentPlayer = 1
            }
        }
        
    else{
        let controller : UIAlertController = UIAlertController(
            title: "Alert!",
            message: "You cannot play this tile. It is already occupied.",
            preferredStyle: UIAlertControllerStyle.alert)
        
        let okAction : UIAlertAction = UIAlertAction(
            title: "Okay",
            style: UIAlertActionStyle.default,
            handler: {(alert: UIAlertAction!) in controller.dismiss(animated: true, completion: nil) })
        controller.addAction(okAction)
        self.present(controller, animated: true, completion: nil)
        }

        

        
                for permutation in winningCombination
                    {
                        if (board[permutation[0]] != 0 && board[permutation[0]] == board[permutation[1]] && board[permutation[1]] == board[permutation[2]] )
                            {
                                startGame = false
                                playAgainButt.isHidden = false
                                
                                if(board[permutation[0]] == 1){
                                    //Red has won
                                    let controller : UIAlertController = UIAlertController(
                                        title: "Congrats Red!",
                                        message: "Red Player has won.",
                                        preferredStyle: UIAlertControllerStyle.alert)
                                    
                                    let okAction : UIAlertAction = UIAlertAction(
                                        title: "Okay",
                                        style: UIAlertActionStyle.default,
                                        handler: {(alert: UIAlertAction!) in controller.dismiss(animated: true, completion: nil) })
                                    controller.addAction(okAction)
                                    self.present(controller, animated: true, completion: nil)
                      
                                }
                                
                                else{
                                    let controller : UIAlertController = UIAlertController(
                                        title: "Congrats Yello",
                                        message: "Yellow Player has won.",
                                        preferredStyle: UIAlertControllerStyle.alert)
                                    
                                    let okAction : UIAlertAction = UIAlertAction(
                                        title: "Okay",
                                        style: UIAlertActionStyle.default,
                                        handler: {(alert: UIAlertAction!) in controller.dismiss(animated: true, completion: nil) })
                                    controller.addAction(okAction)
                                    self.present(controller, animated: true, completion: nil)
                                  
                                  
                                }
                               
                
                            }
                
                    }
        
   
        
        startGame = false
         for loop in board
         {
            if (loop == 0)
            {
                startGame = true
                break
            }
        }
        if startGame == false
        {
            let controller : UIAlertController = UIAlertController(
                title: "Draw",
                message: "There are no winner. It is a tie",
                preferredStyle: UIAlertControllerStyle.alert)
            
            let okAction : UIAlertAction = UIAlertAction(
                title: "Okay",
                style: UIAlertActionStyle.default,
                handler: {(alert: UIAlertAction!) in controller.dismiss(animated: true, completion: nil) })
            controller.addAction(okAction)
            self.present(controller, animated: true, completion: nil)
            playAgainButt.isHidden = false

        }
        
    }
    
    

    @IBAction func playAgain(_ sender: UIButton) {
        board = [0,0,0,0,0,0,0,0,0]
        startGame = true
        
     
        if(self.currentPlayer == 1){
            currentPlayer = 2
        }
        else if(self.currentPlayer == 2){
            currentPlayer = 1
        }
        
        playAgainButt.isHidden = true
        
        for count in 1...9
        {
            let button = view.viewWithTag(count) as! UIButton
            button.setImage(nil, for: UIControlState())
        }
        
    }
    
    
    

}

    


