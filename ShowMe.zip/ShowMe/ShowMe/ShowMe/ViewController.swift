//
//  ViewController.swift
//  ShowMe
//
//  Created by Sergey A. Kutylev on 1/25/2017.
//  Copyright © 2017 salahuddin. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var LabelTitle: UILabel!
    @IBOutlet weak var textToSendField: UITextField!
    @IBOutlet var showmeBUtt: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.textToSendField.delegate = self
       
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event:
        
        UIEvent?) {
        
        self.view.endEditing(true)
        
    }
    
    func textFieldShouldReturn(_ textToSendField: UITextField) -> Bool {
        
        textToSendField.resignFirstResponder()
        
        return true
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //         Get the new view controller using segue.destinationViewController.
        //         Pass the selected object to the new view controller.
        let messageController = segue.destination as! SecondViewController
        
        messageController.messageData = textToSendField.text

    }


    @IBAction func showMeButt(_ sender: UIButton) {
        
        
   
    }
    
    
}
