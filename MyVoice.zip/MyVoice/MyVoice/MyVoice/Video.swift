//
//  Video.swift
//  MyVoice
//
//  Created by Sergey A. Kutylev on 23/05/2017.
//  Copyright © 2017 salahuddin. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation
import MediaPlayer
class Video: UIViewController {

    @IBAction func firstVideo(_ sender: UIButton) {
        let videoURL = URL(string: "https://www.dropbox.com/s/bxia77rfduxwmjt/8%20Phrases%20You%20Need%20To%20Know%20In%20American%20Sign%20Language.mp4?dl=1")
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    
    @IBAction func singnVideo(_ sender: UIButton) {
        let videoURL = URL(string: "https://www.dropbox.com/s/55g4zics7pteknl/25%20Basic%20ASL%20Signs%20For%20Beginners%20-%20Learn%20ASL%20American%20Sign%20Language.mp4?dl=1")
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    
    @IBAction func kidsVideo(_ sender: UIButton) {
        let videoURL = URL(string: "https://www.dropbox.com/s/7wwarczkyyivwhy/ASL%20ABC%20Lesson%20and%20Song%20-%20Learn%20Sign%20Language%20Alphabet.mp4?dl=1")
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    
    @IBAction func alphaVideo(_ sender: UIButton) {
        let videoURL = URL(string: "https://www.dropbox.com/s/7wwarczkyyivwhy/ASL%20ABC%20Lesson%20and%20Song%20-%20Learn%20Sign%20Language%20Alphabet.mp4?dl=1")
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    
    @IBAction func grettingVideo(_ sender: UIButton) {
        let videoURL = URL(string: "https://www.dropbox.com/s/184s4gvmksfvjki/ASL%20Basic%20Conversation.mp4?dl=1")
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //let videoURLWithPath = "http://devstreaming.apple.com/videos/wwdc/2016/102w0bsn0ge83qfv7za/102/hls_vod_mvp.m3u8"
//        let videoURL = URL(string: "https://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4")
//        let player = AVPlayer(url: videoURL!)
//        let playerLayer = AVPlayerLayer(player: player)
//        playerLayer.frame = CGRect(x: 10, y: 10, width: 300, height: 300)
//        self.view.layer.addSublayer(playerLayer)
//
//        player.play()
 

    }
  
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
