//
//  CollectionViewController.swift
//  MyVoice
//
//  Created by Sergey A. Kutylev on 14/04/2017.
//  Copyright © 2017 salahuddin. All rights reserved.
//

import UIKit

class CollectionViewController: UICollectionViewController {
  
var imageViewArray = [UIImage]()
    override func viewDidLoad() {
        super.viewDidLoad()
 imageViewArray = [#imageLiteral(resourceName: "s3"),#imageLiteral(resourceName: "s11"),#imageLiteral(resourceName: "s4"),#imageLiteral(resourceName: "s12"),#imageLiteral(resourceName: "s15"),#imageLiteral(resourceName: "s2"),#imageLiteral(resourceName: "s10"),#imageLiteral(resourceName: "s6"),#imageLiteral(resourceName: "s12"),#imageLiteral(resourceName: "s20"),#imageLiteral(resourceName: "s16"),#imageLiteral(resourceName: "s13"),#imageLiteral(resourceName: "s14"),#imageLiteral(resourceName: "s18"),#imageLiteral(resourceName: "s9"),#imageLiteral(resourceName: "s17"),#imageLiteral(resourceName: "s1"),#imageLiteral(resourceName: "s2"),#imageLiteral(resourceName: "s5")]
        
        // Do any additional setup after loading the view.
      
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
       /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageViewArray.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! UICollectionViewCell
        
        var imageView = cell.viewWithTag(1) as! UIImageView
       imageView.image = imageViewArray[indexPath.row]
        
    return cell
   }
    


}
