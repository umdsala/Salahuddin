//
//  TweetCell.swift
//  MySocialApp
//
//  Created by Sergey A. Kutylev on 3/6/2017.
//  Copyright © 2017 salahuddin. All rights reserved.
//

import UIKit

class TweetCell: UITableViewCell {
    
    @IBOutlet var tweetUserAvatar: UIImageView!
    @IBOutlet var tweetUsername: UILabel!
    @IBOutlet var tweetContent: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
